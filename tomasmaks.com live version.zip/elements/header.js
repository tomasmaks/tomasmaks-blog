

// <a href="about.html">Find out more about me</a>

document.write(`


<div class="profile-section pt-3 pt-lg-0">

<img class="profile-image mb-3 rounded-circle mx-auto" src="assets/images/profile.png" alt="image" >			

<div class="bio mb-3">Hello, my name is Tomas Maksimavicius. I think about myself as generalist. I have some knowledge in programming, writing, startup strategies, e-commerce and I love reading about tech, philosophy and psychology.

<br>
<br>
My goal of the next 5 years is to build products that help small businesses and freelancers. Want to join? Send me DM.
<br>
<br>
</div>

<!--//bio-->
<ul class="social-list list-inline py-3 mx-auto">
    <li class="list-inline-item"><a href="https://www.facebook.com/tomas.maksimavicius/" target="_blank"><i class="fab fa-facebook fa-fw"></i></a></li>
    <li class="list-inline-item"><a href="https://twitter.com/tom_maks" target="_blank"><i class="fab fa-twitter fa-fw"></i></a></li>
    <li class="list-inline-item"><a href="https://www.linkedin.com/in/tomas-maksimavi%C4%8Dius-7a70a6b5/" target="_blank"><i class="fab fa-linkedin-in fa-fw"></i></a></li>
    <li class="list-inline-item"><a href="https://github.com/tomasmaks" target="_blank"><i class="fab fa-github-alt fa-fw"></i></a></li>
</ul>
<!--//social-list-->
<hr> 

</div>
<!--//profile-section-->


`);