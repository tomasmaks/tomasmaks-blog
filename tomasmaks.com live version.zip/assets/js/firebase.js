
  var firebaseConfig = {
    apiKey: "AIzaSyB4_6rbq_rarkZ9puGtAFxKVnuCXLnihUk",
    authDomain: "tomasmaks-blog.firebaseapp.com",
    projectId: "tomasmaks-blog",
    storageBucket: "tomasmaks-blog.appspot.com",
    messagingSenderId: "1005053539163",
    appId: "1:1005053539163:web:54b5d5ecfe4a41cfca607e",
    measurementId: "G-F1E3X6FEQP"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

